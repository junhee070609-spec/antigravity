import React from 'react';
import type { Category } from '../types';
import { CATEGORIES, CATEGORY_THEMES } from '../types';
import { Utensils, Car, ShoppingBag, Home, Film, HelpCircle } from 'lucide-react';

interface CategoryStatsProps {
  expenses: { category: Category; amount: number }[];
  totalAmount: number;
}

const CATEGORY_ICONS: Record<Category, React.ReactNode> = {
  '식비': <Utensils className="h-4 w-4" />,
  '교통비': <Car className="h-4 w-4" />,
  '쇼핑': <ShoppingBag className="h-4 w-4" />,
  '주거비': <Home className="h-4 w-4" />,
  '문화/여가': <Film className="h-4 w-4" />,
  '기타': <HelpCircle className="h-4 w-4" />,
};

export const CategoryStats: React.FC<CategoryStatsProps> = ({ expenses, totalAmount }) => {
  // 1. 카테고리별 합계 계산 및 병합
  const statsMap = expenses.reduce((acc, curr) => {
    acc[curr.category] = (acc[curr.category] || 0) + curr.amount;
    return acc;
  }, {} as Record<Category, number>);

  // 2. 데이터가 없는 카테고리는 제외하고 지출이 있는 항목만 내림차순 정렬
  const statsList = Object.entries(statsMap)
    .map(([category, amount]) => ({
      category: category as Category,
      amount,
      percentage: totalAmount > 0 ? Math.round((amount / totalAmount) * 100) : 0,
    }))
    .filter(item => item.amount > 0)
    .sort((a, b) => b.amount - a.amount);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('ko-KR').format(amount) + '원';
  };

  return (
    <div className="rounded-3xl border border-slate-100 bg-white p-6 shadow-sm dark:border-slate-800 dark:bg-slate-900/40 dark:backdrop-blur-md transition-all duration-300">
      <div className="mb-6">
        <h3 className="text-lg font-bold text-slate-900 dark:text-white">주요 소비 카테고리</h3>
        <p className="text-xs text-slate-500 dark:text-slate-400">어디에 가장 돈을 많이 썼는지 한눈에 파악하세요</p>
      </div>

      {statsList.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-10 text-center">
          <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-slate-50 dark:bg-slate-800 text-slate-400">
            <HelpCircle className="h-6 w-6 animate-pulse" />
          </div>
          <p className="mt-4 text-sm font-medium text-slate-500 dark:text-slate-400">이번 달 지출 내역이 없습니다.</p>
          <p className="text-xs text-slate-400 dark:text-slate-500">새 지출을 등록해 보세요!</p>
        </div>
      ) : (
        <div className="flex flex-col gap-5">
          {statsList.map(({ category, amount, percentage }) => {
            const theme = CATEGORY_THEMES[category];
            return (
              <div key={category} className="group flex flex-col gap-2">
                <div className="flex items-center justify-between text-sm">
                  <div className="flex items-center gap-2">
                    <div className={`flex h-8 w-8 items-center justify-center rounded-xl ${theme.bg} ${theme.text} transition-transform duration-300 group-hover:scale-110`}>
                      {CATEGORY_ICONS[category]}
                    </div>
                    <span className="font-semibold text-slate-800 dark:text-slate-200">{category}</span>
                    <span className="text-xs text-slate-400 dark:text-slate-500">{percentage}%</span>
                  </div>
                  <span className="font-bold text-slate-950 dark:text-white">{formatCurrency(amount)}</span>
                </div>
                
                {/* 게이지 바 */}
                <div className="h-2.5 w-full rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
                  <div
                    className={`h-full rounded-full ${theme.accent} transition-all duration-500 ease-out`}
                    style={{ width: `${percentage}%` }}
                  ></div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
