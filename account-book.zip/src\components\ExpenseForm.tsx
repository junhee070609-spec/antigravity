import React, { useState } from 'react';
import type { Category, Expense } from '../types';
import { CATEGORIES } from '../types';
import { PlusCircle, Calendar, Tag, CreditCard, FileText } from 'lucide-react';

interface ExpenseFormProps {
  onAddExpense: (expense: Omit<Expense, 'id'>) => void;
}

export const ExpenseForm: React.FC<ExpenseFormProps> = ({ onAddExpense }) => {
  const [displayAmount, setDisplayAmount] = useState(''); // 화면에 보여줄 쉼표 포맷팅된 금액
  const [usage, setUsage] = useState('');
  // 기본값을 오늘 날짜(KST 기준 YYYY-MM-DD)로 설정
  const [date, setDate] = useState(() => {
    const today = new Date();
    const offset = today.getTimezoneOffset() * 60000;
    const localISOTime = (new Date(today.getTime() - offset)).toISOString().slice(0, 10);
    return localISOTime;
  });
  const [category, setCategory] = useState<Category>('식비');
  const [memo, setMemo] = useState('');

  // 금액 입력 시 한글/영문 차단 및 천 단위 콤마 포맷팅
  const handleAmountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const rawValue = e.target.value.replace(/[^0-9]/g, '');
    if (rawValue === '') {
      setDisplayAmount('');
      return;
    }
    const numericValue = parseInt(rawValue, 10);
    if (!isNaN(numericValue)) {
      setDisplayAmount(new Intl.NumberFormat('ko-KR').format(numericValue));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    // 쉼표 제거 후 숫자로 파싱
    const cleanAmount = parseInt(displayAmount.replace(/,/g, ''), 10);

    if (!cleanAmount || cleanAmount <= 0) {
      alert('올바른 지출 금액을 입력해 주세요.');
      return;
    }
    if (!usage.trim()) {
      alert('사용처를 입력해 주세요.');
      return;
    }
    if (!date) {
      alert('날짜를 선택해 주세요.');
      return;
    }

    onAddExpense({
      amount: cleanAmount,
      usage: usage.trim(),
      date,
      category,
      memo: memo.trim() || undefined,
    });

    // 폼 입력 리셋 (날짜는 기본 오늘 날짜 유지)
    setDisplayAmount('');
    setUsage('');
    setMemo('');
  };

  return (
    <div className="rounded-3xl border border-slate-100 bg-white p-6 shadow-sm dark:border-slate-800 dark:bg-slate-900/40 dark:backdrop-blur-md transition-all duration-300">
      <div className="mb-6">
        <h3 className="text-lg font-bold text-slate-900 dark:text-white">새로운 지출 등록</h3>
        <p className="text-xs text-slate-500 dark:text-slate-400">지출 내역을 입력하여 가계부에 반영하세요</p>
      </div>

      <form onSubmit={handleSubmit} className="flex flex-col gap-4">
        {/* 지출 금액 입력 */}
        <div className="flex flex-col gap-1.5">
          <label className="text-xs font-semibold text-slate-500 dark:text-slate-400 flex items-center gap-1">
            <CreditCard className="h-3.5 w-3.5" />
            금액 (원)
          </label>
          <div className="relative">
            <input
              type="text"
              required
              placeholder="0"
              value={displayAmount}
              onChange={handleAmountChange}
              className="w-full rounded-2xl border border-slate-700 bg-slate-800 py-3 pl-4 pr-10 text-base font-bold text-white placeholder-slate-400 outline-none transition-all focus:border-brand-500 focus:bg-slate-900 focus:ring-4 focus:ring-brand-900/30 dark:border-slate-800 dark:bg-slate-950 dark:focus:border-brand-500 dark:focus:ring-brand-950/20"
            />
            <span className="absolute right-4 top-1/2 -translate-y-1/2 text-sm font-semibold text-slate-400">원</span>
          </div>
        </div>

        {/* 사용처 입력 */}
        <div className="flex flex-col gap-1.5">
          <label className="text-xs font-semibold text-slate-500 dark:text-slate-400 flex items-center gap-1">
            <PlusCircle className="h-3.5 w-3.5" />
            사용처
          </label>
          <input
            type="text"
            required
            placeholder="예: 스타벅스, 이마트"
            value={usage}
            onChange={(e) => setUsage(e.target.value)}
            className="w-full rounded-2xl border border-slate-700 bg-slate-800 p-3 text-sm font-medium text-white placeholder-slate-400 outline-none transition-all focus:border-brand-500 focus:bg-slate-900 focus:ring-4 focus:ring-brand-900/30 dark:border-slate-800 dark:bg-slate-950 dark:focus:border-brand-500 dark:focus:ring-brand-950/20"
          />
        </div>

        {/* 날짜 & 카테고리 (2열 구성) */}
        <div className="grid grid-cols-2 gap-4">
          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-semibold text-slate-500 dark:text-slate-400 flex items-center gap-1">
              <Calendar className="h-3.5 w-3.5" />
              날짜
            </label>
            <input
              type="date"
              required
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="w-full rounded-2xl border border-slate-700 bg-slate-800 p-3 text-sm font-medium text-white outline-none transition-all focus:border-brand-500 focus:bg-slate-900 focus:ring-4 focus:ring-brand-900/30 dark:border-slate-800 dark:bg-slate-950 dark:focus:border-brand-500 dark:focus:ring-brand-950/20 [color-scheme:dark]"
            />
          </div>

          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-semibold text-slate-500 dark:text-slate-400 flex items-center gap-1">
              <Tag className="h-3.5 w-3.5" />
              카테고리
            </label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value as Category)}
              className="w-full rounded-2xl border border-slate-700 bg-slate-800 p-3 text-sm font-medium text-white outline-none transition-all focus:border-brand-500 focus:bg-slate-900 focus:ring-4 focus:ring-brand-900/30 dark:border-slate-800 dark:bg-slate-950 dark:focus:border-brand-500 dark:focus:ring-brand-950/20 appearance-none"
            >
              {CATEGORIES.map((cat) => (
                <option key={cat} value={cat} className="bg-slate-900 text-white">
                  {cat}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* 메모 (선택사항) */}
        <div className="flex flex-col gap-1.5">
          <label className="text-xs font-semibold text-slate-500 dark:text-slate-400 flex items-center gap-1">
            <FileText className="h-3.5 w-3.5" />
            메모 (선택)
          </label>
          <input
            type="text"
            placeholder="추가 기록 사항"
            value={memo}
            onChange={(e) => setMemo(e.target.value)}
            className="w-full rounded-2xl border border-slate-700 bg-slate-800 p-3 text-sm font-medium text-white placeholder-slate-400 outline-none transition-all focus:border-brand-500 focus:bg-slate-900 focus:ring-4 focus:ring-brand-900/30 dark:border-slate-800 dark:bg-slate-950 dark:focus:border-brand-500 dark:focus:ring-brand-950/20"
          />
        </div>

        {/* 추가 버튼 */}
        <button
          type="submit"
          className="mt-2 w-full cursor-pointer rounded-2xl bg-brand-600 py-3 text-sm font-bold text-white shadow-lg shadow-brand-500/20 transition-all hover:bg-brand-700 hover:shadow-brand-500/30 active:scale-[0.98]"
        >
          지출 내역 등록
        </button>
      </form>
    </div>
  );
};
