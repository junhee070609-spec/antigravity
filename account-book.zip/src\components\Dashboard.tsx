import React from 'react';
import { TrendingUp, TrendingDown, DollarSign } from 'lucide-react';

interface DashboardProps {
  currentMonthExpenses: number;
  prevMonthExpenses: number;
  selectedYear: number;
  selectedMonth: number;
}

export const Dashboard: React.FC<DashboardProps> = ({
  currentMonthExpenses,
  prevMonthExpenses,
  selectedYear,
  selectedMonth,
}) => {
  const diff = currentMonthExpenses - prevMonthExpenses;
  const isIncreased = diff > 0;
  const percentChange = prevMonthExpenses > 0 
    ? Math.round((Math.abs(diff) / prevMonthExpenses) * 100) 
    : 0;

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('ko-KR', { style: 'currency', currency: 'KRW' }).format(amount);
  };

  return (
    <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-violet-600 to-indigo-700 p-6 text-white shadow-xl shadow-indigo-500/10 dark:shadow-none transition-all duration-300 hover:shadow-2xl hover:shadow-indigo-500/20">
      {/* 백그라운드 디자인 서클 */}
      <div className="absolute -right-10 -top-10 h-40 w-40 rounded-full bg-white/10 blur-2xl"></div>
      <div className="absolute -left-10 -bottom-10 h-40 w-40 rounded-full bg-indigo-500/30 blur-2xl"></div>

      <div className="relative z-10 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <span className="text-xs font-semibold tracking-wider text-indigo-100 uppercase">
            {selectedYear}년 {selectedMonth}월 총지출
          </span>
          <h2 className="mt-2 text-3xl md:text-4xl font-extrabold tracking-tight">
            {formatCurrency(currentMonthExpenses)}
          </h2>
        </div>

        <div className="flex flex-col gap-2 rounded-2xl bg-white/10 p-4 backdrop-blur-md border border-white/10 min-w-[200px]">
          <div className="flex items-center justify-between text-xs text-indigo-100">
            <span>지난달 ({selectedMonth === 1 ? 12 : selectedMonth - 1}월) 대비</span>
            {prevMonthExpenses > 0 && (
              isIncreased ? (
                <span className="flex items-center gap-0.5 text-red-300 font-bold">
                  <TrendingUp className="h-3 w-3" />
                  {percentChange}%
                </span>
              ) : (
                <span className="flex items-center gap-0.5 text-emerald-300 font-bold">
                  <TrendingDown className="h-3 w-3" />
                  {percentChange}%
                </span>
              )
            )}
          </div>
          <div className="text-sm font-semibold">
            {prevMonthExpenses === 0 ? (
              <span className="text-indigo-200">비교 데이터 없음</span>
            ) : isIncreased ? (
              <span className="text-red-200">{formatCurrency(diff)} 더 썼어요 📈</span>
            ) : diff === 0 ? (
              <span className="text-indigo-200">지난달과 동일해요 ⚖️</span>
            ) : (
              <span className="text-emerald-200">{formatCurrency(Math.abs(diff))} 아꼈어요 📉</span>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
