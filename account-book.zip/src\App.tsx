import { useState, useEffect } from 'react';
import type { Expense, Category } from './types';
import { Dashboard } from './components/Dashboard';
import { CategoryStats } from './components/CategoryStats';
import { ExpenseForm } from './components/ExpenseForm';
import { ExpenseList } from './components/ExpenseList';
import { Sun, Moon, Calendar, ChevronLeft, ChevronRight, TrendingUp } from 'lucide-react';

// 첫 방문 사용자를 위해 현재 날짜 기준으로 동적 생성할 가상 데이터
const getInitialMockData = (): Expense[] => {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  
  // 지난달 계산
  let prevYear = year;
  let prevMonthNum = now.getMonth(); // 0-indexed 이므로 이전 달 번호
  if (prevMonthNum === 0) {
    prevMonthNum = 12;
    prevYear -= 1;
  }
  const prevMonth = String(prevMonthNum).padStart(2, '0');

  return [
    {
      id: 'mock-1',
      amount: 450000,
      usage: '주택 월세 납부',
      date: `${year}-${month}-01`,
      category: '주거비',
      memo: '매월 1일 고정 지출'
    },
    {
      id: 'mock-2',
      amount: 6500,
      usage: '스타벅스 아이스 아메리카노',
      date: `${year}-${month}-${String(Math.max(1, now.getDate() - 1)).padStart(2, '0')}`,
      category: '식비',
      memo: '동료와 점심 식사 후 디저트'
    },
    {
      id: 'mock-3',
      amount: 14500,
      usage: '카카오 택시비',
      date: `${year}-${month}-${String(Math.max(1, now.getDate() - 2)).padStart(2, '0')}`,
      category: '교통비',
      memo: '야근 후 귀가'
    },
    {
      id: 'mock-4',
      amount: 98000,
      usage: '이마트 가을 장보기',
      date: `${year}-${month}-${String(Math.max(1, now.getDate() - 3)).padStart(2, '0')}`,
      category: '식비'
    },
    {
      id: 'mock-5',
      amount: 17000,
      usage: '넷플릭스 월간 구독',
      date: `${year}-${month}-${String(Math.max(1, now.getDate() - 4)).padStart(2, '0')}`,
      category: '문화/여가'
    },
    // 지난달 지출 데이터 (대시보드 비교용)
    {
      id: 'mock-prev-1',
      amount: 450000,
      usage: '주택 월세 납부',
      date: `${prevYear}-${prevMonth}-01`,
      category: '주거비'
    },
    {
      id: 'mock-prev-2',
      amount: 112000,
      usage: '백화점 의류 쇼핑',
      date: `${prevYear}-${prevMonth}-15`,
      category: '쇼핑',
      memo: '가을 셔츠 구매'
    },
    {
      id: 'mock-prev-3',
      amount: 85000,
      usage: '빕스 외식',
      date: `${prevYear}-${prevMonth}-20`,
      category: '식비',
      memo: '가족 모임 식사'
    }
  ];
};

function App() {
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [selectedYear, setSelectedYear] = useState(() => new Date().getFullYear());
  const [selectedMonth, setSelectedMonth] = useState(() => new Date().getMonth() + 1);
  const [darkMode, setDarkMode] = useState(() => {
    // 로컬 스토리지 또는 시스템 기본값 감지
    const saved = localStorage.getItem('darkMode');
    if (saved) return saved === 'true';
    return window.matchMedia('(prefers-color-scheme: dark)').matches;
  });

  // 1. 컴포넌트 마운트 시 LocalStorage에서 지출 내역 로드
  useEffect(() => {
    const savedExpenses = localStorage.getItem('expenses');
    if (savedExpenses) {
      try {
        setExpenses(JSON.parse(savedExpenses));
      } catch (e) {
        console.error('Failed to parse expenses from LocalStorage', e);
        const initialMock = getInitialMockData();
        setExpenses(initialMock);
        localStorage.setItem('expenses', JSON.stringify(initialMock));
      }
    } else {
      // 데이터가 없는 최초 방문자에게 모크 데이터 제공
      const initialMock = getInitialMockData();
      setExpenses(initialMock);
      localStorage.setItem('expenses', JSON.stringify(initialMock));
    }
  }, []);

  // 2. expenses 상태가 바뀔 때마다 LocalStorage 자동 동기화
  const saveExpenses = (newExpenses: Expense[]) => {
    setExpenses(newExpenses);
    localStorage.setItem('expenses', JSON.stringify(newExpenses));
  };

  // 3. 다크모드 동기화
  useEffect(() => {
    const root = window.document.documentElement;
    if (darkMode) {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
    localStorage.setItem('darkMode', String(darkMode));
  }, [darkMode]);

  // 4. 지출 추가 및 삭제 처리
  const handleAddExpense = (newExpenseData: Omit<Expense, 'id'>) => {
    const newExpense: Expense = {
      ...newExpenseData,
      id: `expense-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
    };
    saveExpenses([newExpense, ...expenses]);
  };

  const handleDeleteExpense = (id: string) => {
    if (window.confirm('이 지출 내역을 정말 삭제하시겠습니까?')) {
      const updated = expenses.filter((exp) => exp.id !== id);
      saveExpenses(updated);
    }
  };

  // 5. 선택한 월 이동 핸들러
  const handlePrevMonth = () => {
    if (selectedMonth === 1) {
      setSelectedMonth(12);
      setSelectedYear(selectedYear - 1);
    } else {
      setSelectedMonth(selectedMonth - 1);
    }
  };

  const handleNextMonth = () => {
    if (selectedMonth === 12) {
      setSelectedMonth(1);
      setSelectedYear(selectedYear + 1);
    } else {
      setSelectedMonth(selectedMonth + 1);
    }
  };

  // 6. 지출 계산 및 필터링
  // 6-1. 선택된 년/월의 지출만 필터링
  const currentMonthExpensesList = expenses.filter((exp) => {
    const expDate = new Date(exp.date);
    return expDate.getFullYear() === selectedYear && (expDate.getMonth() + 1) === selectedMonth;
  });

  const currentMonthTotal = currentMonthExpensesList.reduce((sum, exp) => sum + exp.amount, 0);

  // 6-2. 이전 달(selectedMonth - 1)의 지출만 필터링하여 총액 계산
  let prevYear = selectedYear;
  let prevMonth = selectedMonth - 1;
  if (prevMonth === 0) {
    prevMonth = 12;
    prevYear -= 1;
  }

  const prevMonthExpensesList = expenses.filter((exp) => {
    const expDate = new Date(exp.date);
    return expDate.getFullYear() === prevYear && (expDate.getMonth() + 1) === prevMonth;
  });

  const prevMonthTotal = prevMonthExpensesList.reduce((sum, exp) => sum + exp.amount, 0);

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 transition-colors duration-300 dark:bg-slate-950 dark:text-slate-100">
      {/* 헤더 바 */}
      <header className="sticky top-0 z-40 w-full border-b border-slate-100/80 bg-white/70 backdrop-blur-md dark:border-slate-900/80 dark:bg-slate-950/70">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-brand-600 text-white shadow-md shadow-brand-500/20">
              <TrendingUp className="h-5 w-5" />
            </div>
            <div>
              <h1 className="text-lg font-black tracking-tight text-slate-950 dark:text-white sm:text-xl">
                소비록 <span className="text-brand-500">Sobirok</span>
              </h1>
              <p className="text-[10px] font-semibold text-slate-400 dark:text-slate-500">프리미엄 지출 관리 파트너</p>
            </div>
          </div>

          <button
            onClick={() => setDarkMode(!darkMode)}
            className="flex h-10 w-10 cursor-pointer items-center justify-center rounded-2xl border border-slate-200 bg-white text-slate-500 shadow-sm transition-all hover:bg-slate-50 hover:text-brand-600 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-400 dark:hover:bg-slate-800 dark:hover:text-brand-400"
            title={darkMode ? '라이트 모드로 변경' : '다크 모드로 변경'}
          >
            {darkMode ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
          </button>
        </div>
      </header>

      {/* 메인 레이아웃 */}
      <main className="mx-auto max-w-6xl px-6 py-8">
        <div className="flex flex-col gap-6">
          
          {/* 년/월 선택 네비게이터 */}
          <div className="flex items-center justify-between rounded-2xl bg-white p-4 shadow-sm border border-slate-100 dark:bg-slate-900/30 dark:border-slate-900/60">
            <button
              onClick={handlePrevMonth}
              className="flex h-10 w-10 cursor-pointer items-center justify-center rounded-xl bg-slate-50 text-slate-600 transition-all hover:bg-brand-50 hover:text-brand-600 dark:bg-slate-900 dark:text-slate-400 dark:hover:bg-brand-950/30 dark:hover:text-brand-400"
              title="이전 달"
            >
              <ChevronLeft className="h-5 w-5" />
            </button>
            
            <div className="flex items-center gap-2 text-base font-bold text-slate-950 dark:text-white">
              <Calendar className="h-5 w-5 text-brand-500" />
              <span>{selectedYear}년 {selectedMonth}월</span>
            </div>

            <button
              onClick={handleNextMonth}
              className="flex h-10 w-10 cursor-pointer items-center justify-center rounded-xl bg-slate-50 text-slate-600 transition-all hover:bg-brand-50 hover:text-brand-600 dark:bg-slate-900 dark:text-slate-400 dark:hover:bg-brand-950/30 dark:hover:text-brand-400"
              title="다음 달"
            >
              <ChevronRight className="h-5 w-5" />
            </button>
          </div>

          {/* 대시보드 카드 */}
          <Dashboard
            currentMonthExpenses={currentMonthTotal}
            prevMonthExpenses={prevMonthTotal}
            selectedYear={selectedYear}
            selectedMonth={selectedMonth}
          />

          {/* 통계와 입력/내역 그리드 분할 */}
          <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
            
            {/* 좌측 컬럼: 통계 및 입력 폼 (lg:col-span-5) */}
            <div className="flex flex-col gap-6 lg:col-span-5">
              <CategoryStats
                expenses={currentMonthExpensesList}
                totalAmount={currentMonthTotal}
              />
              <ExpenseForm onAddExpense={handleAddExpense} />
            </div>

            {/* 우측 컬럼: 지출 리스트 (lg:col-span-7) */}
            <div className="lg:col-span-7">
              <ExpenseList
                expenses={currentMonthExpensesList}
                onDeleteExpense={handleDeleteExpense}
              />
            </div>

          </div>
        </div>
      </main>
    </div>
  );
}

export default App;
