import React, { useState } from 'react';
import type { Expense, Category } from '../types';
import { CATEGORIES, CATEGORY_THEMES } from '../types';
import { Trash2, Search, Filter, Utensils, Car, ShoppingBag, Home, Film, HelpCircle, Calendar } from 'lucide-react';

interface ExpenseListProps {
  expenses: Expense[];
  onDeleteExpense: (id: string) => void;
}

const CATEGORY_ICONS: Record<Category, React.ReactNode> = {
  '식비': <Utensils className="h-4 w-4" />,
  '교통비': <Car className="h-4 w-4" />,
  '쇼핑': <ShoppingBag className="h-4 w-4" />,
  '주거비': <Home className="h-4 w-4" />,
  '문화/여가': <Film className="h-4 w-4" />,
  '기타': <HelpCircle className="h-4 w-4" />,
};

export const ExpenseList: React.FC<ExpenseListProps> = ({ expenses, onDeleteExpense }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<Category | '전체'>('전체');

  // 최신순 정렬 (날짜 내림차순, 같은 날짜면 ID 기준 내림차순)
  const sortedExpenses = [...expenses].sort((a, b) => {
    if (a.date !== b.date) {
      return new Date(b.date).getTime() - new Date(a.date).getTime();
    }
    return b.id.localeCompare(a.id);
  });

  // 검색어와 카테고리 필터 적용
  const filteredExpenses = sortedExpenses.filter(expense => {
    const matchesSearch = expense.usage.toLowerCase().includes(searchTerm.toLowerCase()) || 
      (expense.memo && expense.memo.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesCategory = selectedCategory === '전체' || expense.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('ko-KR').format(amount) + '원';
  };

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    const days = ['일', '월', '화', '수', '목', '금', '토'];
    return `${date.getMonth() + 1}월 ${date.getDate()}일 (${days[date.getDay()]})`;
  };

  return (
    <div className="rounded-3xl border border-slate-100 bg-white p-6 shadow-sm dark:border-slate-800 dark:bg-slate-900/40 dark:backdrop-blur-md transition-all duration-300">
      {/* 상단 타이틀 & 검색 필터 툴바 */}
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between mb-6">
        <div>
          <h3 className="text-lg font-bold text-slate-900 dark:text-white">지출 상세 내역</h3>
          <p className="text-xs text-slate-500 dark:text-slate-400">이번 달 등록된 지출 목록입니다</p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* 검색 바 */}
          <div className="relative flex-1 min-w-[150px] md:flex-none">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="사용처, 메모 검색"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full rounded-xl border border-slate-700 bg-slate-800 py-2 pl-9 pr-4 text-xs font-medium text-white placeholder-slate-400 outline-none transition-all focus:border-brand-500 focus:bg-slate-900 dark:border-slate-800 dark:bg-slate-950 dark:focus:border-brand-500"
            />
          </div>

          {/* 카테고리 필터 */}
          <div className="relative">
            <Filter className="absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-slate-400" />
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value as Category | '전체')}
              className="rounded-xl border border-slate-700 bg-slate-800 py-2 pl-8 pr-6 text-xs font-semibold text-white outline-none transition-all focus:border-brand-500 focus:bg-slate-900 dark:border-slate-800 dark:bg-slate-950 dark:focus:border-brand-500 appearance-none"
            >
              <option value="전체" className="bg-slate-900 text-white">전체 카테고리</option>
              {CATEGORIES.map(cat => (
                <option key={cat} value={cat} className="bg-slate-900 text-white">{cat}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* 내역 리스트 */}
      {filteredExpenses.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-16 text-center">
          <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-slate-50 dark:bg-slate-800 text-slate-400">
            <Search className="h-5 w-5" />
          </div>
          <p className="mt-4 text-sm font-medium text-slate-500 dark:text-slate-400">
            {searchTerm || selectedCategory !== '전체' ? '검색 조건과 일치하는 지출 내역이 없습니다.' : '내역이 존재하지 않습니다.'}
          </p>
        </div>
      ) : (
        <div className="flex flex-col gap-3 max-h-[500px] overflow-y-auto pr-1">
          {filteredExpenses.map((expense) => {
            const theme = CATEGORY_THEMES[expense.category];
            return (
              <div
                key={expense.id}
                className="group flex items-center justify-between rounded-2xl border border-slate-100/70 bg-white p-4 shadow-sm transition-all duration-200 hover:border-brand-200 hover:shadow-md dark:border-slate-800/50 dark:bg-slate-900/60 dark:hover:border-brand-900/50"
              >
                <div className="flex items-center gap-3">
                  {/* 카테고리 아이콘 */}
                  <div className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl ${theme.bg} ${theme.text}`}>
                    {CATEGORY_ICONS[expense.category]}
                  </div>

                  {/* 지출 정보 */}
                  <div className="flex flex-col">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-slate-800 dark:text-slate-200 text-sm md:text-base">
                        {expense.usage}
                      </span>
                      <span className={`rounded-lg px-2 py-0.5 text-[10px] font-bold ${theme.bg} ${theme.text}`}>
                        {expense.category}
                      </span>
                    </div>
                    
                    <div className="mt-0.5 flex flex-wrap items-center gap-x-2 text-xs text-slate-400 dark:text-slate-500">
                      <span className="flex items-center gap-1">
                        <Calendar className="h-3 w-3" />
                        {formatDate(expense.date)}
                      </span>
                      {expense.memo && (
                        <>
                          <span className="text-slate-300 dark:text-slate-700">•</span>
                          <span className="truncate max-w-[150px] italic">{expense.memo}</span>
                        </>
                      )}
                    </div>
                  </div>
                </div>

                {/* 우측 금액 및 삭제 버튼 */}
                <div className="flex items-center gap-4">
                  <span className="font-extrabold text-slate-950 dark:text-white text-sm md:text-base">
                    {formatCurrency(expense.amount)}
                  </span>
                  
                  <button
                    onClick={() => onDeleteExpense(expense.id)}
                    className="flex h-8 w-8 cursor-pointer items-center justify-center rounded-xl bg-slate-50 text-slate-400 transition-all hover:bg-red-50 hover:text-red-500 dark:bg-slate-800 dark:text-slate-500 dark:hover:bg-red-950/30 dark:hover:text-red-400"
                    title="지출 삭제"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
